\#AQI Search Engine



A simple Air Quality Index (AQI) Search Engine that allows users to check real-time AQI of any city using a clean frontend and a Node.js backend.



\##Project Structure



aqi-search-engine/

│

├── backend/

│   ├── server.js

│   ├── routes/

│   │     └── aqiRoutes.js

│   ├── controllers/

│   │     └── aqiController.js

│   ├── services/

│   │     └── aqiService.js

│   ├── cache/

│   │     └── cache.js

│   └── config/

│         └── apiConfig.js

│

└── frontend/

&nbsp;   ├── index.html

&nbsp;   ├── style.css

&nbsp;   └── script.js



\##Features



🔍 Search real-time AQI of any city



⚡ Fast performance using caching



🌐 Fetches data from external AQI API



🎨 Clean and simple UI



🛠 Node.js + Express backend





\##Requirements



* Make sure the following are installed:



* Node.js (version 14 or above)



* npm (comes with Node.js)



* A code editor like VS Code



\##Backend Setup



\###Go to backend folder

cd backend



\###Install all dependencies

npm install



\###Configure your API Key

Open:

backend/config/apiConfig.js



Add your API key:

module.exports = {

&nbsp; AQI\_API\_URL: "https://api.waqi.info/feed",

&nbsp; API\_KEY: "your\_api\_key\_here"

};



\###Start the backend server



node server.js



Your backend will run at:

http://localhost:5000



\##Frontend Setup



Open the frontend folder



Open index.html directly in your browser (or use Live Server extension in VS Code)



\##API Endpoint

GET /api/aqi/:city



Example:

http://localhost:5000/api/aqi/pune



\##Testing the Project



Start backend server



Open frontend → index.html



Enter city name → Get real-time AQI results



\##Project Purpose



This project demonstrates:



API Integration



Full Stack (Frontend + Backend)



Node.js Caching



Clean folder structure





\##License



Free to use for learning and portfolio projects.







