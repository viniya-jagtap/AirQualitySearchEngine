import axios from "axios";
import { API_TOKEN, BASE_URL } from "../config/apiConfig.js";
import { getCache, setCache } from "../cache/cache.js";

export const getAQI = async (city) => {
  const key = city.toLowerCase();
  const cached = getCache(key);
  if (cached) return { data: cached, cached: true };

  try {
    const url = `${BASE_URL}/${encodeURIComponent(city)}/?token=${API_TOKEN}`;
    const res = await axios.get(url);
    if (res.data.status === "ok") {
      setCache(key, res.data);
      return { data: res.data, cached: false };
    }
    return null;
  } catch (err) {
    console.error(err.message);
    return null;
  }
};
