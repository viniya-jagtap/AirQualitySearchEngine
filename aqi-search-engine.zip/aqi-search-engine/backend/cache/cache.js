const cache = new Map();
const TTL = 5 * 60 * 1000; // 5 minutes

export const setCache = (key, value) => {
  cache.set(key, { value, time: Date.now() });
  // max 50 entries
  if (cache.size > 50) {
    const oldest = cache.keys().next().value;
    cache.delete(oldest);
  }
};

export const getCache = (key) => {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.time > TTL) {
    cache.delete(key);
    return null;
  }
  return entry.value;
};
