import { getAQI } from "../services/aqiService.js";

export const fetchAQI = async (req, res) => {
  const city = (req.query.city || "").trim();
  if (!city) return res.status(400).json({ error: "City is required" });

  const result = await getAQI(city);
  if (!result) return res.status(404).json({ error: "City not found" });

  res.json(result);
};
