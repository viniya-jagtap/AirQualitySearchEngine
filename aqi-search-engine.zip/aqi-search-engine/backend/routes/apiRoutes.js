import express from "express";
import { fetchAQI } from "../controllers/aqiController.js";

const router = express.Router();

router.get("/", fetchAQI);

export default router;
