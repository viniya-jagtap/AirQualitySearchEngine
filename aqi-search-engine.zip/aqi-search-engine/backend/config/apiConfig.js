export const AQI_API_URL = "https://api.waqi.info/feed";
export const AQI_TOKEN = "YOUR_API_KEY_HERE"; 
