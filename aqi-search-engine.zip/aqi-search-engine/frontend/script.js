const btn = document.getElementById("btn");
const cityInput = document.getElementById("city");
const statusDiv = document.getElementById("status");
const resultDiv = document.getElementById("result");

btn.addEventListener("click", async ()=>{
  const city = cityInput.value.trim();
  if(!city){ statusDiv.textContent="Enter city"; return;}
  statusDiv.textContent="Searching...";
  resultDiv.innerHTML="";
  try{
    const res = await fetch(`http://localhost:5000/api/aqi?city=${encodeURIComponent(city)}`);
    const json = await res.json();
    if(!res.ok){statusDiv.textContent=json.error||"Error"; return;}
    statusDiv.textContent = json.cached?"From Cache":"Fresh Data";

    const aqi = json.data.aqi;
    const dom = json.data.dominentpol;
    const cityName = json.data.city.name;

    const card = document.createElement("div");
    card.className="card";
    card.innerHTML=`<strong>${cityName}</strong><br>AQI: <span class="aqi">${aqi}</span> | Dominant: ${dom}`;
    resultDiv.appendChild(card);
  }catch(err){statusDiv.textContent="Error fetching data";}
});
